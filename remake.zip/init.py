# DO NOT TOUCH
from flask import *
app = Flask(__name__)
app.secret_key = "secret"
# DO NOT TOUCH

@app.route("/")
def show_index():
    return render_template("index.html")

app.run()